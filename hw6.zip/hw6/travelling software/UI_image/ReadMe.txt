Developed as a part of Internship in Y.M.U. Pvt Ltd Noida from Dec 2016 to Jan 2017.

I created an interactive Java GUI [Graphical User Interface] for the
employees of this company. I used JavaFX and swing. GUI has an
interactive interface with various options like add/edit/delete & update clients and to view vast balance sheet etc and to convert data into excel sheet for ease of employees of Company.

JavaFX is new GUI framework introduced with Java-8. Its functionalities are similar to Android in many ways.